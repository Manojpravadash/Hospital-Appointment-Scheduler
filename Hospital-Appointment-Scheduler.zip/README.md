# Hospital Appointment Scheduler

A demo full-stack web application for booking and managing hospital appointments. Includes patient registration, booking, doctor dashboard, and a simple admin panel.

## How to run locally
1. Install XAMPP/WAMP and start Apache & MySQL.
2. Copy this project folder to your `htdocs` (or www) folder.
3. Import `db/create_tables.sql` into MySQL.
4. Update `db/connection.php` with your MySQL credentials.
5. Open `http://localhost/Hospital-Appointment-Scheduler/index.html` in your browser.

## Notes
- This is a demo scaffold: authentication and security are simplified for clarity. For production, implement stronger validation, prepared statements (already used), HTTPS, CSRF protection, and secure password policies.
- You can deploy static frontend using Firebase Hosting and point backend PHP to a proper PHP hosting provider.
