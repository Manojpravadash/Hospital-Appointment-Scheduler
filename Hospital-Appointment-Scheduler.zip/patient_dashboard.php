<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'patient') { header('Location: login.html'); exit; }
require 'db/connection.php';
$user = $_SESSION['user_name'];
?>
<!doctype html><html><head><meta charset="utf-8"><title>Patient Dashboard</title><link rel="stylesheet" href="css/style.css"></head>
<body><div class="container"><h2>Welcome, <?php echo htmlspecialchars($user); ?></h2>
<p><a href="book_appointment.php">Book Appointment</a></p>
<p><a href="db/logout.php">Logout</a></p></div></body></html>
