<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'doctor') { header('Location: login.html'); exit; }
require 'db/connection.php';
$doctor_id = $_SESSION['user_id'];
$appointments = $conn->prepare('SELECT a.*, p.name as patient_name FROM appointments a JOIN patients p ON a.patient_id=p.id WHERE a.doctor_id=? ORDER BY a.appointment_date');
$appointments->bind_param('i',$doctor_id); $appointments->execute(); $res = $appointments->get_result();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Doctor Dashboard</title><link rel="stylesheet" href="css/style.css"></head>
<body><div class="container"><h2>Doctor Dashboard</h2><ul><?php while($row = $res->fetch_assoc()){ echo '<li>'.htmlspecialchars($row['appointment_date']).' '.htmlspecialchars($row['appointment_time']).' - '.htmlspecialchars($row['patient_name']).' ('.htmlspecialchars($row['status']).')</li>'; } ?></ul></div></body></html>
