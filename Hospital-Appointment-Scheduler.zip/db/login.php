<?php
session_start();
require 'connection.php';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$role = $_POST['role'] ?? 'patient';
if (!$email || !$password) { header('Location: ../login.html'); exit; }

if ($role === 'patient') {
  $stmt = $conn->prepare('SELECT id,name,password FROM patients WHERE email=?');
  $stmt->bind_param('s',$email);
  $stmt->execute();
  $res = $stmt->get_result();
  if ($row = $res->fetch_assoc()) {
    if (password_verify($password, $row['password'])) {
      $_SESSION['user_id']=$row['id']; $_SESSION['user_name']=$row['name']; $_SESSION['role']='patient';
      header('Location: ../patient_dashboard.php'); exit;
    }
  }
} elseif ($role === 'doctor') {
  $stmt = $conn->prepare('SELECT id,name FROM doctors WHERE email=?');
  $stmt->bind_param('s',$email); $stmt->execute();
  $res = $stmt->get_result();
  if ($row = $res->fetch_assoc()) {
    // skipping password check for demo; implement properly in production
    $_SESSION['user_id']=$row['id']; $_SESSION['user_name']=$row['name']; $_SESSION['role']='doctor';
    header('Location: ../doctor_dashboard.php'); exit;
  }
} else {
  // simple admin check - in production use proper auth
  if ($email === 'admin@example.com' && $password === 'adminpass') {
    $_SESSION['role']='admin'; header('Location: ../admin_dashboard.php'); exit;
  }
}
echo 'Login failed';
?>
