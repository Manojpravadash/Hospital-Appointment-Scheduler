<?php
session_start();
require 'db/connection.php';
// Simple booking form for demo purposes: select doctor and date/time
$doctors = $conn->query('SELECT id,name,specialization FROM doctors');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $patient_id = $_SESSION['user_id'];
  $doctor_id = $_POST['doctor_id'];
  $date = $_POST['date'];
  $time = $_POST['time'];
  $stmt = $conn->prepare('INSERT INTO appointments (patient_id,doctor_id,appointment_date,appointment_time) VALUES (?,?,?,?)');
  $stmt->bind_param('iiss',$patient_id,$doctor_id,$date,$time);
  if ($stmt->execute()) { echo 'Appointment booked successfully.'; } else { echo 'Error: '. $conn->error; }
  exit;
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Book Appointment</title><link rel="stylesheet" href="css/style.css"></head>
<body><div class="form-card"><h3>Book Appointment</h3>
<form method="post">
<label>Doctor</label><select name="doctor_id"><?php while($d=$doctors->fetch_assoc()){ echo '<option value="'.$d['id'].'">'.htmlspecialchars($d['name']).' - '.htmlspecialchars($d['specialization']).'</option>'; } ?></select>
<label>Date</label><input type="date" name="date" required>
<label>Time</label><input type="time" name="time" required>
<button type="submit">Book</button></form></div></body></html>
