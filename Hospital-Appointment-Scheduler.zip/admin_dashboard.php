<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') { header('Location: login.html'); exit; }
require 'db/connection.php';
$stats = [];
$res = $conn->query('SELECT COUNT(*) as cnt FROM patients'); $stats['patients'] = $res->fetch_assoc()['cnt'];
$res = $conn->query('SELECT COUNT(*) as cnt FROM doctors'); $stats['doctors'] = $res->fetch_assoc()['cnt'];
$res = $conn->query('SELECT COUNT(*) as cnt FROM appointments'); $stats['appointments'] = $res->fetch_assoc()['cnt'];
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin Dashboard</title><link rel="stylesheet" href="css/style.css"></head>
<body><div class="container"><h2>Admin Dashboard</h2><p>Patients: <?php echo $stats['patients']; ?></p><p>Doctors: <?php echo $stats['doctors']; ?></p><p>Appointments: <?php echo $stats['appointments']; ?></p></div></body></html>
